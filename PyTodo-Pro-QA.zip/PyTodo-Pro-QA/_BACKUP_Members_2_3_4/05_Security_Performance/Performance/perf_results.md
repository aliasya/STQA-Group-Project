# Performance Results (generated)

Environment: Linux 6.18.44-fc-v819, Python 3.13.18, 2 logical CPUs, Flask dev server (threaded), SQLite

Workload: levels [1, 5, 10, 20, 50] concurrent users; 20 requests/user (5 for login); 50 tasks in DB; no think time.

| Endpoint | Users | Requests | Mean (ms) | Median (ms) | p95 (ms) | Max (ms) | Throughput (req/s) | Error rate (%) |
|---|---|---|---|---|---|---|---|---|
| GET /api/tasks?per_page=50 | 1 | 20 | 2.9 | 2.8 | 3.1 | 4.6 | 134.0 | 0.0 |
| GET /api/tasks?per_page=50 | 5 | 100 | 26.3 | 26.7 | 46.8 | 59.1 | 132.9 | 0.0 |
| GET /api/tasks?per_page=50 | 10 | 200 | 55.3 | 54.7 | 107.5 | 156.8 | 119.1 | 0.0 |
| GET /api/tasks?per_page=50 | 20 | 400 | 135.6 | 104.7 | 303.5 | 418.3 | 105.6 | 0.0 |
| GET /api/tasks?per_page=50 | 50 | 1000 | 542.7 | 613.2 | 811.3 | 1077.5 | 74.9 | 0.0 |
| GET /api/dashboard | 1 | 20 | 3.2 | 3.2 | 3.4 | 3.9 | 122.4 | 0.0 |
| GET /api/dashboard | 5 | 100 | 14.9 | 13.2 | 27.2 | 43.1 | 172.0 | 0.0 |
| GET /api/dashboard | 10 | 200 | 36.0 | 33.9 | 58.6 | 86.3 | 167.9 | 0.0 |
| GET /api/dashboard | 20 | 400 | 70.0 | 68.2 | 107.2 | 158.7 | 172.0 | 0.0 |
| GET /api/dashboard | 50 | 1000 | 204.9 | 196.6 | 287.2 | 516.5 | 159.4 | 0.0 |
| GET / (HTML list) | 1 | 20 | 4.5 | 4.0 | 4.7 | 13.5 | 112.8 | 0.0 |
| GET / (HTML list) | 5 | 100 | 32.7 | 32.6 | 55.5 | 63.9 | 114.4 | 0.0 |
| GET / (HTML list) | 10 | 200 | 77.4 | 71.6 | 152.7 | 211.4 | 98.5 | 0.0 |
| GET / (HTML list) | 20 | 400 | 156.5 | 141.2 | 325.2 | 407.6 | 96.0 | 0.0 |
| GET / (HTML list) | 50 | 1000 | 673.8 | 734.4 | 947.6 | 1149.1 | 62.5 | 0.0 |
| POST /api/login | 1 | 5 | 102.3 | 102.5 | 104.8 | 105.9 | 8.0 | 0.0 |
| POST /api/login | 5 | 25 | 227.2 | 226.8 | 281.5 | 293.9 | 17.8 | 0.0 |
| POST /api/login | 10 | 50 | 396.5 | 399.3 | 437.8 | 457.1 | 19.8 | 0.0 |
| POST /api/login | 20 | 100 | 772.5 | 757.0 | 919.7 | 1004.2 | 20.7 | 0.0 |
| POST /api/login | 50 | 250 | 1974.9 | 2002.3 | 2318.7 | 2887.7 | 19.9 | 0.0 |
